from socket import *
import sys

serverIP = '127.0.0.1'
serverPort = 12000

clientSocket = socket(AF_INET, SOCK_DGRAM)
port=sys.argv[1]
message = sys.argv[2]


clientSocket.bind(('',int(port)))

clientSocket.sendto(message.encode(), (serverIP, serverPort))
modifiedMessage, serverAddress = clientSocket.recvfrom(2048)
print (modifiedMessage.decode())

clientSocket.close()

